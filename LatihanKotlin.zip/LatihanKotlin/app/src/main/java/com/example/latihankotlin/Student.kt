package com.example.latihankotlin


fun main() {

}

